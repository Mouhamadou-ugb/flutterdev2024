import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:superbiz/firebase_options.dart';
import 'acceuille.dart';
import 'connexion.dart';
import 'inscription.dart';
import 'entreprise.dart';
import 'entreprise_employe.dart';
import 'paiement_employe.dart';
import 'reunion.dart';
import 'reunion_employe.dart';
import 'paiement.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Superbiz',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const AcceuillePage(), 
      routes: {
        '/connexion': (context) => const ConnexionPage(),
        '/inscription': (context) => const InscriptionPage(),
        '/entreprise': (context) => const EntreprisePage(),
        '/entreprise_employe': (context) => const EntrepriseEmployePage(),
        '/reunion': (context) => ReunionPage(),
        '/reunion_employe': (context) => ReunionEmployePage(),
        '/paiement': (context) => const PaiementPage(),
        '/paiement_employe': (context) => const PaiementEmployePage(),

      },
    );
  }
}
