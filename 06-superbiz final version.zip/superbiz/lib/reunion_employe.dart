import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ReunionEmployePage extends StatelessWidget {
  const ReunionEmployePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications de Réunion'),
        backgroundColor: Colors.blue,
      ),
      body: StreamBuilder<QuerySnapshot>(
        
        stream: FirebaseFirestore.instance
            .collection('notifications')
            .where('type', isEqualTo: 'reunion')  
            .orderBy('heure', descending: true)   
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            print("Erreur Firestore : ${snapshot.error}");
            return const Center(
              child: Text('Une erreur est survenue lors du chargement des notifications'),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('Aucune notification de réunion disponible'),
            );
          }

          
          final notifications = snapshot.data!.docs;

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final notification = notifications[index];
              final message = notification['message'] ?? 'Message non spécifié';
              final timestamp = notification['heure'] as Timestamp?;  
              
              String formattedDate = 'Date inconnue';
              if (timestamp != null) {
                final date = timestamp.toDate();  
                formattedDate = '${date.day.toString().padLeft(2, '0')}/'
                              '${date.month.toString().padLeft(2, '0')}/'
                              '${date.year} à '
                              '${date.hour.toString().padLeft(2, '0')}:'
                              '${date.minute.toString().padLeft(2, '0')}';
              }

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                elevation: 2.0,
                child: ListTile(
                  leading: const Icon(Icons.notifications, color: Colors.blue),
                  title: Text(
                    message,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  subtitle: Text(
                    'Envoyé le : $formattedDate',
                    style: const TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}