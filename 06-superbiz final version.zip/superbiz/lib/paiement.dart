import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PaiementPage extends StatefulWidget {
  const PaiementPage({Key? key}) : super(key: key);

  @override
  State<PaiementPage> createState() => _PaiementPageState();
}

class _PaiementPageState extends State<PaiementPage> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedEmployeId;
  String _montant = '';
  String _selectedMethodePaiement = 'wave';
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isLoading = false;

  String formatDate(DateTime date) {
    String padding(int n) => n.toString().padLeft(2, '0');
    return "${padding(date.day)}/${padding(date.month)}/${date.year} ${padding(date.hour)}:${padding(date.minute)}";
  }

  Future<List<QueryDocumentSnapshot>> _fetchEmployes() async {
    final employesQuery = await _firestore.collection('employes').get();
    return employesQuery.docs;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Paiement des salaires'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                
                FutureBuilder<List<QueryDocumentSnapshot>>(
                  future: _fetchEmployes(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Erreur: ${snapshot.error}');
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircularProgressIndicator();
                    }

                    final employes = snapshot.data!;
                    List<DropdownMenuItem<String>> employeItems = employes.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return DropdownMenuItem(
                        value: doc.id,
                        child: Text('${data['nom']} ${data['prenom']}'),
                      );
                    }).toList();

                    return DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Sélectionner un employé',
                        border: OutlineInputBorder(),
                      ),
                      value: _selectedEmployeId,
                      items: employeItems,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Veuillez sélectionner un employé';
                        }
                        return null;
                      },
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedEmployeId = newValue;
                        });
                      },
                    );
                  },
                ),

                const SizedBox(height: 20),

                
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Montant',
                    border: OutlineInputBorder(),
                    prefixText: 'FCFA ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer un montant';
                    }
                    if (int.tryParse(value) == null) {
                      return 'Veuillez entrer un nombre valide';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    _montant = value;
                  },
                ),

                const SizedBox(height: 20),

                
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Méthode de paiement',
                    border: OutlineInputBorder(),
                  ),
                  value: _selectedMethodePaiement,
                  items: const [
                    DropdownMenuItem(value: 'wave', child: Text('Wave')),
                    DropdownMenuItem(value: 'orange_money', child: Text('Orange Money')),
                  ],
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedMethodePaiement = newValue!;
                    });
                  },
                ),

                const SizedBox(height: 30),

                
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    backgroundColor: Colors.blue,
                  ),
                  onPressed: _isLoading ? null : _effectuerPaiement,
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                          'Effectuer le paiement',
                          style: TextStyle(fontSize: 18),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _effectuerPaiement() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        throw Exception('Aucun utilisateur connecté');
      }

      
      await _firestore.collection('paiements').add({
        'id_employe': _selectedEmployeId,
        'montant': int.parse(_montant),
        'methode_paiement': _selectedMethodePaiement,
        'date_paiement': Timestamp.now(),
        'id_admin': currentUser.uid,
        'status': 'termine',
      });

      
      _formKey.currentState!.reset();
      setState(() {
        _selectedEmployeId = null;
        _montant = '';
        _selectedMethodePaiement = 'wave';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Paiement effectué avec succès!'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors du paiement: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
