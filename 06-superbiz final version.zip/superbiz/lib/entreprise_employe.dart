import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'reunion_employe.dart';
import 'paiement_employe.dart';



class EntrepriseEmployePage extends StatelessWidget {
  const EntrepriseEmployePage({Key? key}) : super(key: key);

  Future<void> _deconnecter(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/connexion');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Menu',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
      
            ListTile(
              leading: const Icon(Icons.payment),
              title: const Text('Paiement des salaires'),
              onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PaiementEmployePage()),
                  );
              },
            ),
            ListTile(
              leading: const Icon(Icons.group),
              title: const Text('Réunion'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReunionEmployePage()),
                );
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(64, 0, 0, 0),
        elevation: 0,
        leading: Builder(
          builder: (context) {
            return IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'Déconnecter') {
                _deconnecter(context);
              }
            },
            icon: const Icon(Icons.account_circle, size: 30, color: Colors.white),
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'Paramètres', child: Text('Paramètres')),
              const PopupMenuItem(value: 'Compte', child: Text('Compte')),
              const PopupMenuItem(value: 'Langue', child: Text('Langue')),
              const PopupMenuItem(value: 'Confidentialité', child: Text('Confidentialité')),
              const PopupMenuDivider(),
              const PopupMenuItem(value: 'Déconnecter', child: Text('Déconnecter')),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/fonts/font2.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 100), 

                  
                  Container(
                    margin: const EdgeInsets.only(bottom: 20.0),
                    padding: const EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Actualités de l'entreprise",
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const SizedBox(width: 10),
                            Expanded(
                              child: Image.asset('assets/images/image2.jpg', height: 100),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          "Derniers faits marquants et activités internes.",
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),

                  
                  Container(
                    padding: const EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Informations sur l'entreprise",
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        Image.asset('assets/images/image3.jpg', height: 120),
                        const SizedBox(height: 10),
                        const Text(
                          "Origine : Fondée en 2000\nÉvaluation : Excellente\nÉtat actuel : En expansion",
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
