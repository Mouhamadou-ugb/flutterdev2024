import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PaiementEmployePage extends StatelessWidget {
  const PaiementEmployePage({Key? key}) : super(key: key);

  Future<String?> _getEmployeId() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return null;

    
    final docSnapshot =
        await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    if (docSnapshot.exists) {
      return user.uid;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes Paiements'),
        backgroundColor: Colors.blue,
      ),
      body: FutureBuilder<String?>(
        future: _getEmployeId(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || snapshot.data == null) {
            return const Center(child: Text('Erreur lors du chargement des données.'));
          }

          final employeId = snapshot.data!;
          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('salaire')
                .where('employe_id', isEqualTo: employeId)
                .orderBy('date_paiement', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('Erreur lors du chargement des paiements.'));
              }
              final paiements = snapshot.data?.docs ?? [];
              if (paiements.isEmpty) {
                return const Center(child: Text('Aucun paiement reçu.'));
              }

              return ListView.builder(
                itemCount: paiements.length,
                itemBuilder: (context, index) {
                  final paiement = paiements[index];
                  final montant = paiement['montant'] ?? 0.0;
                  final datePaiement = paiement['date_paiement'] as Timestamp?;
                  final formattedDate = datePaiement != null
                      ? DateTime.fromMillisecondsSinceEpoch(
                              datePaiement.millisecondsSinceEpoch)
                          .toString()
                      : 'Date inconnue';

                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                    child: ListTile(
                      leading: const Icon(Icons.payment, color: Colors.green),
                      title: Text(
                        'Montant reçu : ${montant.toStringAsFixed(2)} FCFA',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Date de paiement : $formattedDate'),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
