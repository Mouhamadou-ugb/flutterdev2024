package com.example.superbiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
