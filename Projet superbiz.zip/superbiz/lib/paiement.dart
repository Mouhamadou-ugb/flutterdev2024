import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';


class PaiementLien extends StatefulWidget {
  const PaiementLien({Key? key}) : super(key: key);

  @override
  _PaiementLienState createState() => _PaiementLienState();
}

class _PaiementLienState extends State<PaiementLien> {
  final _formKey = GlobalKey<FormState>();
  final _montantController = TextEditingController();
  String? _selectedEmployeId;
  String? _selectedEmployeName;
  String? _selectedMethodePaiement;
  bool _isLoading = false;

  
  final List<String> _methodesPaiement = ['Wave', 'Orange Money'];

  
  Stream<QuerySnapshot> _getEmployes() {
    return FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: 'employe')
        .snapshots();
  }

  
  Future<void> _effectuerPaiement() async {
    if (!_formKey.currentState!.validate() || _selectedEmployeId == null || _selectedMethodePaiement == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez remplir tous les champs')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      
      final adminEmail = FirebaseAuth.instance.currentUser?.email;
      final adminDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: adminEmail)
          .get();

      if (adminDoc.docs.isEmpty) {
        throw Exception('Admin non trouvé');
      }

      final adminId = adminDoc.docs.first['cin'];

      
      await FirebaseFirestore.instance.collection('paiements').add({
        'employeId': _selectedEmployeId,
        'adminId': adminId,
        'montant': double.parse(_montantController.text),
        'methode_paiement': _selectedMethodePaiement,
        'date_paiement': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paiement effectué avec succès')),
      );

      
      _montantController.clear();
      setState(() {
        _selectedEmployeId = null;
        _selectedMethodePaiement = null;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur : ${e.toString()}')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Paiements'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              
              StreamBuilder<QuerySnapshot>(
                stream: _getEmployes(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return const Text('Erreur lors du chargement des employés');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  }

                  final employes = snapshot.data?.docs ?? [];
                  return DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      labelText: 'Sélectionner un employé',
                      border: OutlineInputBorder(),
                    ),
                    value: _selectedEmployeId,
                    items: employes.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return DropdownMenuItem<String>(
                        value: data['cin'],
                        child: Text('${data['nom']} ${data['prenom']}'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedEmployeId = value;
                        _selectedEmployeName = employes
                            .firstWhere((doc) => doc['cin'] == value)['nom'];
                      });
                    },
                  );
                },
              ),
              const SizedBox(height: 16),

              
              TextFormField(
                controller: _montantController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Montant',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer un montant';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Veuillez entrer un montant valide';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Méthode de paiement',
                  border: OutlineInputBorder(),
                ),
                value: _selectedMethodePaiement,
                items: _methodesPaiement.map((methode) {
                  return DropdownMenuItem<String>(
                    value: methode,
                    child: Text(methode),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedMethodePaiement = value;
                  });
                },
              ),
              const SizedBox(height: 16),

              
              ElevatedButton(
                onPressed: _isLoading ? null : _effectuerPaiement,
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('Effectuer le paiement'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _montantController.dispose();
    super.dispose();
  }
}
