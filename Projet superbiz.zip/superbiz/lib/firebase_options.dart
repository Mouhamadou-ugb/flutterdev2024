import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;


class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBzuJkPlH1MDLl6Uu74ZF8MNHDLKK0NxlQ',
    appId: '1:630568770548:web:62dd7249aaffc5f8a7b7a1',
    messagingSenderId: '630568770548',
    projectId: 'superbiz-da7d1',
    authDomain: 'superbiz-da7d1.firebaseapp.com',
    storageBucket: 'superbiz-da7d1.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDTvqcTq8EPQXANJ5aDSDGRToKXnGthh_4',
    appId: '1:630568770548:android:de4ed33c3e7f5646a7b7a1',
    messagingSenderId: '630568770548',
    projectId: 'superbiz-da7d1',
    storageBucket: 'superbiz-da7d1.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAJ85d-eZ-TBFLwyaVQuARQpmi_awxFEkA',
    appId: '1:630568770548:ios:2fdf7979f2752a41a7b7a1',
    messagingSenderId: '630568770548',
    projectId: 'superbiz-da7d1',
    storageBucket: 'superbiz-da7d1.firebasestorage.app',
    iosBundleId: 'com.example.superbiz',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyAJ85d-eZ-TBFLwyaVQuARQpmi_awxFEkA',
    appId: '1:630568770548:ios:2fdf7979f2752a41a7b7a1',
    messagingSenderId: '630568770548',
    projectId: 'superbiz-da7d1',
    storageBucket: 'superbiz-da7d1.firebasestorage.app',
    iosBundleId: 'com.example.superbiz',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyBzuJkPlH1MDLl6Uu74ZF8MNHDLKK0NxlQ',
    appId: '1:630568770548:web:7015acc25dcc08eca7b7a1',
    messagingSenderId: '630568770548',
    projectId: 'superbiz-da7d1',
    authDomain: 'superbiz-da7d1.firebaseapp.com',
    storageBucket: 'superbiz-da7d1.firebasestorage.app',
  );
}
