import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ReunionLien extends StatefulWidget {
  const ReunionLien({Key? key}) : super(key: key);

  @override
  State<ReunionLien> createState() => _ReunionLienState();
}

class _ReunionLienState extends State<ReunionLien> {
  final TextEditingController _messageController = TextEditingController();
  bool _isAddingNew = false;

  Future<void> _envoyerNotification() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Le message est vide !")),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('notifications').add({
        'type': 'reunion',
        'message': message,
        'heure': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Notification envoyée avec succès !")),
      );
      _messageController.clear();
      setState(() {
        _isAddingNew = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erreur : ${e.toString()}")),
      );
    }
  }

  Widget _buildAddNotificationForm() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            "Message de la réunion",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _messageController,
            maxLines: 3,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Ex: Réunion prévue demain à 10h",
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  setState(() {
                    _isAddingNew = false;
                    _messageController.clear();
                  });
                },
                child: const Text("Annuler"),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _envoyerNotification,
                child: const Text("Envoyer"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Gestion des réunions"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          if (_isAddingNew) _buildAddNotificationForm(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('notifications')
                  .where('type', isEqualTo: 'reunion')
                  .orderBy('heure', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(
                    child: Text('Erreur: ${snapshot.error}'),
                  );
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(
                    child: Text('Aucune notification de réunion'),
                  );
                }

                return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    final doc = snapshot.data!.docs[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final message = data['message'] ?? '';
                    final timestamp = data['heure'] as Timestamp;
                    final date = timestamp.toDate();
                    final formattedDate = 
                        '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year} à ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';

                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        leading: const Icon(Icons.event, color: Colors.blue),
                        title: Text(
                          message,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text('Envoyé le: $formattedDate'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () async {
                            try {
                              await doc.reference.delete();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("Notification supprimée"),
                                ),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text("Erreur lors de la suppression: $e"),
                                ),
                              );
                            }
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: !_isAddingNew ? FloatingActionButton(
        onPressed: () {
          setState(() {
            _isAddingNew = true;
          });
        },
        child: const Icon(Icons.add),
      ) : null,
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
}