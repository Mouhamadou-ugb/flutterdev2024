import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class OrdreMissionLien extends StatefulWidget {
  const OrdreMissionLien({Key? key}) : super(key: key);

  @override
  _OrdreMissionLienState createState() => _OrdreMissionLienState();
}

class _OrdreMissionLienState extends State<OrdreMissionLien> {
  final _formKey = GlobalKey<FormState>();
  final _messageController = TextEditingController();
  String? _selectedEmployeId;
  String? _selectedEmployeName;
  bool _isLoading = false;

  
  Stream<QuerySnapshot> _getEmployes() {
    return FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: 'employe')
        .snapshots();
  }

 

Future<void> _creerOrdreMission() async {
    if (!_formKey.currentState!.validate() || _selectedEmployeId == null) {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              title: const Text('Attention'),
              content: const Text('Veuillez remplir tous les champs'),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          );
        },
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
  
      final adminDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: FirebaseAuth.instance.currentUser?.email)
          .get();

      if (adminDoc.docs.isEmpty) {
        throw Exception('Admin non trouvé');
      }

      String adminCin = adminDoc.docs.first['cin'];

      
      await FirebaseFirestore.instance.collection('ordres_mission').add({
        'employeId': _selectedEmployeId,
        'adminId': adminCin,
        'message': _messageController.text,
        'date': Timestamp.now(),
      });

      
      setState(() {
        _selectedEmployeId = null;
        _messageController.clear();
      });

      
      if (!mounted) return;
      
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              title: const Text('Succès'),
              content: const Text('Ordre de mission créé avec succès'),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          );
        },
      );
    } catch (e) {
      if (!mounted) return;
      
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              title: const Text('Erreur'),
              content: Text('Erreur: ${e.toString()}'),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          );
        },
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Créer un ordre de mission'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              
              StreamBuilder<QuerySnapshot>(
                stream: _getEmployes(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return const Text('Erreur de chargement des employés');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  }

                  final employes = snapshot.data?.docs ?? [];

                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: DropdownButton<String>(
                      isExpanded: true,
                      hint: const Text('Sélectionner un employé'),
                      value: _selectedEmployeId,
                      items: employes.map((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        return DropdownMenuItem<String>(
                          value: data['cin'],
                          child: Text('${data['nom']} ${data['prenom']}'),
                        );
                      }).toList(),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedEmployeId = value;
                          if (value != null) {
                            final selectedDoc = employes.firstWhere(
                                (doc) => doc['cin'] == value);
                            _selectedEmployeName = 
                                '${selectedDoc['nom']} ${selectedDoc['prenom']}';
                          }
                        });
                      },
                    ),
                  );
                },
              ),

              const SizedBox(height: 16),

              
              TextFormField(
                controller: _messageController,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Message de mission',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer un message';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              
              ElevatedButton(
                onPressed: _isLoading ? null : _creerOrdreMission,
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('Envoyer l\'ordre de mission'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
}