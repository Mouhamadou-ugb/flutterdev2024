import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:superbiz/firebase_options.dart';

import 'acceuille.dart';
import 'connexion.dart';
import 'inscription.dart';
import 'entreprise.dart';
import 'entreprise_employe.dart';
import 'paiement.dart';
import 'paiement_employe.dart';
import 'reunion.dart';
import 'reunion_employe.dart';
import 'ordre_de_mission.dart';
import 'ordre_de_mission_employe.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Superbiz',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const AcceuillePage(),
      routes: {
        '/connexion': (context) => const ConnexionLien(),
        '/inscription': (context) => const InscriptionLien(),
        '/entreprise': (context) => const EntrepriseLien(),
        '/entreprise_employe': (context) => const EntrepriseEmployeLien(),
        '/reunion': (context) => ReunionLien(),
        '/reunion_employe': (context) => ReunionEmployeLien(),
        '/paiement': (context) => const PaiementLien(),
        '/paiement_employe': (context) => const PaiementEmployeLien(),
        '/ordre_de_mission': (context) => OrdreMissionLien(),
        '/ordre_de_mission_employe': (context) => OrdreMissionEmployeLien(),
      },
    );
  }
}
