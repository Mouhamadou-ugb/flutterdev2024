import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PaiementEmployeLien extends StatefulWidget {
  const PaiementEmployeLien({Key? key}) : super(key: key);

  @override
  _PaiementEmployeLienState createState() => _PaiementEmployeLienState();
}

class _PaiementEmployeLienState extends State<PaiementEmployeLien> {
  String? _employeId;
  bool _isLoading = true; 

  @override
  void initState() {
    super.initState();
    _fetchEmployeId();
  }

  
  Future<void> _fetchEmployeId() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        throw Exception('Utilisateur non connecté');
      }

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: currentUser.email)
          .get();

      if (userDoc.docs.isEmpty) {
        throw Exception('Employé non trouvé');
      }

      setState(() {
        _employeId = userDoc.docs.first['cin'];
        _isLoading = false; 
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: ${e.toString()}')),
      );
      setState(() {
        _isLoading = false; 
      });
    }
  }

  
  Stream<QuerySnapshot>? _getPaiements() {
    if (_employeId == null) return null;
    return FirebaseFirestore.instance
        .collection('paiements')
        .where('employeId', isEqualTo: _employeId)
        .orderBy('date_paiement', descending: true)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes Paiements'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _employeId == null
              ? const Center(child: Text('Impossible de récupérer vos données'))
              : StreamBuilder<QuerySnapshot>(
                  stream: _getPaiements(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Center(
                        child: Text('Erreur lors du chargement des paiements'),
                      );
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    final paiements = snapshot.data?.docs ?? [];

                    if (paiements.isEmpty) {
                      return const Center(
                        child: Text('Aucun paiement trouvé'),
                      );
                    }

                    return ListView.builder(
                      itemCount: paiements.length,
                      itemBuilder: (context, index) {
                        final data =
                            paiements[index].data() as Map<String, dynamic>;
                        final montant = data['montant'] ?? 0.0;
                        final methode = data['methode_paiement'] ?? 'Inconnue';
                        final date =
                            (data['date_paiement'] as Timestamp).toDate();

                        return ListTile(
                          leading: const Icon(Icons.attach_money),
                          title: Text('Montant : $montant F CFA'),
                          subtitle: Text(
                              'Méthode : $methode\nDate : ${date.toLocal()}'
                                  .split('.')
                                  .first),
                          isThreeLine: true,
                        );
                      },
                    );
                  },
                ),
    );
  }
}
