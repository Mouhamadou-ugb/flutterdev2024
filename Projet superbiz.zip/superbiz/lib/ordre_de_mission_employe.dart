import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class OrdreMissionEmployeLien extends StatefulWidget {
  const OrdreMissionEmployeLien({Key? key}) : super(key: key);

  @override
  _OrdreMissionEmployeLienState createState() => _OrdreMissionEmployeLienState();
}

class _OrdreMissionEmployeLienState extends State<OrdreMissionEmployeLien> {
  String? _employeCin;
  bool _isLoading = true;
  final dateFormat = DateFormat('dd/MM/yyyy HH:mm');

  @override
  void initState() {
    super.initState();
    _getCurrentEmployeCin();
  }


  Future<void> _showErrorDialog(String message) async {
    if (!mounted) return;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async => false,
          child: AlertDialog(
            title: const Text('Erreur'),
            content: Text(message),
            actions: <Widget>[
              TextButton(
                child: const Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _getCurrentEmployeCin() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: FirebaseAuth.instance.currentUser?.email)
          .get();

      if (!mounted) return;

      if (userDoc.docs.isNotEmpty) {
        setState(() {
          _employeCin = userDoc.docs.first.get('cin');
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        await _showErrorDialog('Impossible de trouver vos informations d\'employé');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      await _showErrorDialog('Erreur lors de la récupération de vos informations: ${e.toString()}');
    }
  }

  Stream<QuerySnapshot> _getOrdresMission() {
    return FirebaseFirestore.instance
        .collection('ordres_mission')
        .where('employeId', isEqualTo: _employeCin)
        .orderBy('date', descending: true)
        .snapshots();
  }

  Future<String> _getAdminName(String adminCin) async {
    try {
      final adminDoc = await FirebaseFirestore.instance
          .collection('users')
          .where('cin', isEqualTo: adminCin)
          .limit(1)  
          .get();

      if (adminDoc.docs.isNotEmpty) {
        final admin = adminDoc.docs.first.data() as Map<String, dynamic>;
        return '${admin['nom']} ${admin['prenom']}';
      }
      return 'Admin inconnu';
    } catch (e) {
      return 'Admin inconnu';
    }
  }

  
  Future<void> _retryLoading() async {
    setState(() => _isLoading = true);
    await _getCurrentEmployeCin();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Chargement des ordres de mission...'),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes ordres de mission'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _retryLoading,
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _getOrdresMission(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Erreur de chargement des ordres de mission',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _retryLoading,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Réessayer'),
                  ),
                ],
              ),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          final ordres = snapshot.data?.docs ?? [];

          if (ordres.isEmpty) {
            return const Center(
              child: Text(
                'Aucun ordre de mission',
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: ordres.length,
            itemBuilder: (context, index) {
              final ordre = ordres[index].data() as Map<String, dynamic>;
              final date = (ordre['date'] as Timestamp).toDate();

              return Card(
                elevation: 2,
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Ordre de mission du ${dateFormat.format(date)}'),
                        content: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('Message:\n${ordre['message']}'),
                              const SizedBox(height: 16),
                              FutureBuilder<String>(
                                future: _getAdminName(ordre['adminId']),
                                builder: (context, snapshot) {
                                  return Text(
                                    'Admin: ${snapshot.data ?? 'Chargement...'}',
                                    style: const TextStyle(
                                      fontStyle: FontStyle.italic,
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: const Text('Fermer'),
                          ),
                        ],
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Date: ${dateFormat.format(date)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Message: ${ordre['message']}',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        FutureBuilder<String>(
                          future: _getAdminName(ordre['adminId']),
                          builder: (context, snapshot) {
                            return Text(
                              'Admin: ${snapshot.data ?? 'Chargement...'}',
                              style: const TextStyle(
                                fontStyle: FontStyle.italic,
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}